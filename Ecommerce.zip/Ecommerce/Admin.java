package Ecommerce;

public class Admin {
	String user = "";

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}

	public Boolean verifyAdmin() {
		return true;
	}
}
